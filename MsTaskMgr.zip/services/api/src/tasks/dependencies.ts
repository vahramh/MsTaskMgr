
import type { Task, UpdateTaskRequest, WorkflowState } from "@tm/shared";
import { deriveV2Defaults } from "./gtd";
import { getLookup } from "./sharing";
import { getTask, getSubtask, listAllSubtasks, updateSubtask, updateTask } from "./repo";

export type DependencyTarget = {
  rootTaskId: string;
  parentTaskId?: string;
  taskId: string;
  title: string;
  entityType?: Task["entityType"];
  state: WorkflowState;
};

async function getTaskByLookup(sub: string, taskId: string): Promise<(Task & { rootTaskId: string }) | null> {
  const lookup = await getLookup(sub, taskId);
  if (!lookup) return null;
  const task =
    lookup.kind === "ROOT"
      ? await getTask(sub, taskId)
      : await getSubtask(sub, lookup.parentTaskId!, taskId);
  if (!task) return null;
  return { ...task, rootTaskId: lookup.rootTaskId };
}

async function collectDescendantIds(sub: string, taskId: string): Promise<Set<string>> {
  const out = new Set<string>();
  const queue = [taskId];
  while (queue.length > 0) {
    const parentId = queue.shift()!;
    const children = await listAllSubtasks(sub, parentId);
    for (const child of children) {
      if (!out.has(child.taskId)) {
        out.add(child.taskId);
        queue.push(child.taskId);
      }
    }
  }
  return out;
}

export async function validateStructuredDependency(args: {
  sub: string;
  currentTaskId: string;
  currentRootTaskId: string;
  waitingForTaskId?: string | null;
}): Promise<{ ok: true; blocker?: { taskId: string; title: string } } | { ok: false; message: string }> {
  const blockerId = args.waitingForTaskId?.trim();
  if (!blockerId) return { ok: true };

  if (blockerId === args.currentTaskId) return { ok: false, message: "A task cannot wait on itself" };

  const blocker = await getTaskByLookup(args.sub, blockerId);
  if (!blocker) return { ok: false, message: "Selected blocker task was not found" };
  if (blocker.rootTaskId !== args.currentRootTaskId) return { ok: false, message: "Structured waiting must target a task in the same project" };

  const blockerState = (blocker.state ?? deriveV2Defaults(blocker).state) as WorkflowState;
  const blockerEntityType = blocker.entityType ?? deriveV2Defaults(blocker).entityType;
  if (blockerEntityType !== "action") return { ok: false, message: "Structured waiting can only target action tasks" };
  if (blockerState === "completed") return { ok: false, message: "Cannot wait on a completed task" };
  if (blockerState === "reference" || blockerState === "someday") return { ok: false, message: "Cannot wait on reference or someday items" };

  const descendants = await collectDescendantIds(args.sub, args.currentTaskId);
  if (descendants.has(blockerId)) return { ok: false, message: "A task cannot wait on one of its descendants" };

  return { ok: true, blocker: { taskId: blocker.taskId, title: blocker.title } };
}

function shouldClearFreeText(waitingFor: string | undefined, blockerTitle: string | undefined): boolean {
  const free = (waitingFor ?? "").trim().toLowerCase();
  const blocker = (blockerTitle ?? "").trim().toLowerCase();
  if (!free) return true;
  if (!blocker) return false;
  if (free === blocker) return true;
  if (free === `blocked by ${blocker}`) return true;
  if (free === `waiting on ${blocker}`) return true;
  if (free === `waiting for ${blocker}`) return true;
  return false;
}

export async function releaseTasksBlockedByTask(sub: string, blockerTaskId: string, nowIso: string): Promise<void> {
  const blocker = await getTaskByLookup(sub, blockerTaskId);
  if (!blocker) return;

  const root = await getTask(sub, blocker.rootTaskId);
  if (!root) return;

  const queue: Task[] = [root];
  while (queue.length > 0) {
    const parent = queue.shift()!;
    const children = await listAllSubtasks(sub, parent.taskId);
    queue.push(...children);

    for (const child of children) {
      if (child.waitingForTaskId !== blockerTaskId) continue;
      const state = (child.state ?? deriveV2Defaults(child).state) as WorkflowState;
      if (state !== "waiting") continue;

      const resumeState = child.resumeStateAfterWait ?? "next";
      const patch: UpdateTaskRequest = {
        state: resumeState,
        waitingForTaskId: null,
        waitingForTaskTitle: null,
        resumeStateAfterWait: null,
        waitingFor: shouldClearFreeText(child.waitingFor, child.waitingForTaskTitle) ? null : child.waitingFor ?? null,
      };

      if (child.parentTaskId) await updateSubtask(sub, child.parentTaskId, child.taskId, patch, nowIso);
      else await updateTask(sub, child.taskId, patch, nowIso);
    }
  }
}
