import net from "node:net";
import tls from "node:tls";
type SmtpConfig = { host: string; port: number; secure: boolean; username?: string; password?: string; fromEmail: string; toEmail: string };
function readLine(socket: net.Socket): Promise<string> { return new Promise((resolve, reject) => { let buf = ""; const onData = (data: Buffer) => { buf += data.toString("utf8"); if (/\r?\n$/.test(buf)) { const last = buf.split(/\r?\n/).filter(Boolean).pop() || ""; if (!/^[0-9]{3}-/.test(last)) { socket.off("data", onData); socket.off("error", reject); resolve(buf); } } }; socket.on("data", onData); socket.once("error", reject); }); }
async function cmd(socket: net.Socket, line: string, ok: number[]): Promise<string> { socket.write(line + "\r\n"); const r = await readLine(socket); const code = Number(r.slice(0, 3)); if (!ok.includes(code)) throw new Error(`SMTP command failed (${line.split(" ")[0]}): ${r.trim()}`); return r; }
function addr(email: string) { return email.match(/<([^>]+)>/)?.[1] || email; }
export function esc(s: string) { return s.replace(/[&<>]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]!)); }
export async function sendSmtpEmail(config: SmtpConfig, subject: string, html: string, text: string): Promise<void> {
  let socket: net.Socket = config.secure ? tls.connect(config.port, config.host, { servername: config.host }) : net.connect(config.port, config.host);
  await readLine(socket); await cmd(socket, `EHLO egs.local`, [250]);
  if (!config.secure && config.port === 587) { await cmd(socket, "STARTTLS", [220]); socket = tls.connect({ socket, servername: config.host }); await cmd(socket, `EHLO egs.local`, [250]); }
  if (config.username && config.password) { await cmd(socket, "AUTH LOGIN", [334]); await cmd(socket, Buffer.from(config.username).toString("base64"), [334]); await cmd(socket, Buffer.from(config.password).toString("base64"), [235]); }
  await cmd(socket, `MAIL FROM:<${addr(config.fromEmail)}>`, [250]); await cmd(socket, `RCPT TO:<${addr(config.toEmail)}>`, [250, 251]); await cmd(socket, "DATA", [354]);
  const boundary = `egs-${Date.now()}`;
  const message = [`From: ${config.fromEmail}`, `To: ${config.toEmail}`, `Subject: ${subject}`, "MIME-Version: 1.0", `Content-Type: multipart/alternative; boundary="${boundary}"`, "", `--${boundary}`, "Content-Type: text/plain; charset=utf-8", "", text, `--${boundary}`, "Content-Type: text/html; charset=utf-8", "", html, `--${boundary}--`, ".", ""].join("\r\n");
  socket.write(message); const r = await readLine(socket); if (Number(r.slice(0, 3)) !== 250) throw new Error(`SMTP DATA failed: ${r.trim()}`); await cmd(socket, "QUIT", [221]);
}
