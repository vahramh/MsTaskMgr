# Settings and scheduled recommendations email changes

Implemented:

- Settings screen at `/app/settings`.
- Significant execution-context flag on execution contexts.
- SMTP email server configuration in Settings.
- Notification schedule configuration in Settings.
- Manual `Send recommendation email now` button.
- Scheduled Lambda that checks due notification settings every 15 minutes.
- Recommendation emails grouped by significant execution context, with configurable top-N recommendations per group.

Notes:

- SMTP password is stored in the existing DynamoDB table as part of the user's settings item. This is functional, but for a production hardening pass I would move secrets into AWS Secrets Manager or encrypt this field with KMS.
- Schedule times are entered as local time for the configured timezone. The default timezone is `Australia/Melbourne`.
- The scheduled Lambda uses the existing table's GSI1 to find due notification settings.
