export type HealthResponse = {
  ok: true;
  service: "api";
  time: string;
};

export type TaskStatus = "OPEN" | "COMPLETED";

/**
 * Phase 4 (GTD): First-class workflow state (mutually exclusive).
 * These are enforced domain states (NOT tags).
 */
export type WorkflowState =
  | "inbox"
  | "next"
  | "waiting"
  | "scheduled"
  | "someday"
  | "reference"
  | "completed";

/**
 * Phase 4 (GTD): Entity type.
 */
export type EntityType = "project" | "action";

/** 1 (highest) .. 5 (lowest) */
export type TaskPriority = 1 | 2 | 3 | 4 | 5;


/** Priority helpers with canonical semantics: P1 strongest, P5 weakest. */
export function priorityRank(priority: TaskPriority | undefined | null): number {
  if (priority == null) return 0;
  return 6 - priority;
}

export function priorityLabel(priority: TaskPriority | undefined | null): string {
  switch (priority) {
    case 1: return "P1 · Critical";
    case 2: return "P2 · High";
    case 3: return "P3 · Normal";
    case 4: return "P4 · Low";
    case 5: return "P5 · Very low";
    default: return "No priority";
  }
}

export type EffortUnit = "hours" | "days";
export type DurationUnit = "minutes" | "hours";

export type EffortEstimate = {
  unit: EffortUnit;
  value: number; // positive finite
};

export type DurationEstimate = {
  unit: DurationUnit;
  value: number; // positive finite
};


export type ExecutionContextKind = "place" | "person" | "tool" | "mode" | "energy";

export type ExecutionContext = {
  contextId: string;
  name: string;
  kind: ExecutionContextKind;
  sortOrder: number;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ListExecutionContextsResponse = {
  items: ExecutionContext[];
};

export type CreateExecutionContextRequest = {
  name: string;
  kind: ExecutionContextKind;
  sortOrder?: number;
};

export type CreateExecutionContextResponse = {
  context: ExecutionContext;
};

export type UpdateExecutionContextRequest = {
  name?: string;
  kind?: ExecutionContextKind;
  sortOrder?: number;
  archived?: boolean;
};

export type UpdateExecutionContextResponse = {
  context: ExecutionContext;
};


/**
 * Controlled execution contexts used by the UI for structured filtering and capture.
 * Tasks continue to store context as a serialised string for backward compatibility.
 */
export type ExecutionContextOption =
  | "computer"
  | "phone"
  | "home"
  | "office"
  | "out-and-about"
  | "deep-focus"
  | "light-admin"
  | "low-energy"
  | "calls"
  | "email"
  | "agenda"
  | "quick-win";

export type TaskAttrValue = string | number | boolean | string[];

export type TaskAttributes = Record<string, TaskAttrValue>;

export type Task = {
  taskId: string;

  /** Present when this task is a subtask of another task node. */
  parentTaskId?: string;
  title: string;
  description?: string;

  /** Legacy status retained for compatibility. In Phase 4+, server derives it from `state`. */
  status: TaskStatus;

  // ----------------------------------------------------------------------
  // Phase 4: GTD-native domain fields

  /** Schema version marker for GTD v2 items. */
  schemaVersion?: 2;

  /** Entity type (project|action). Required for v2 items; defaulted during migration. */
  entityType?: EntityType;

  /** Workflow state. Required for v2 items; derived from legacy fields during migration. */
  state?: WorkflowState;

  /** Legacy context string retained for compatibility/display. */
  context?: string;

  /** Canonical execution context identifiers. */
  contextIds?: string[];

  /** Optional free-text note when waiting. */
  waitingFor?: string;

  /** Structured blocker task (same project only in current phase). */
  waitingForTaskId?: string;

  /** Snapshot of blocker title for display. System-managed. */
  waitingForTaskTitle?: string;

  /** State to move to automatically once blocker completes. */
  resumeStateAfterWait?: "inbox" | "next";

  /** Original estimate in minutes for progress-aware execution guidance. */
  estimatedMinutes?: number;

  /** Remaining estimated effort in minutes. */
  remainingMinutes?: number;

  /** Time already spent in minutes. */
  timeSpentMinutes?: number;

  // ----------------------------------------------------------------------

  /** ISO-8601 date or datetime (e.g. 2026-03-10 or 2026-03-10T12:00:00Z) */
  dueDate?: string;

  priority?: TaskPriority;

  effort?: EffortEstimate;

  /** Smallest uninterrupted block worth starting this task. */
  minimumDuration?: DurationEstimate;

  /** User-defined attributes (small, bounded values). */
  attrs?: TaskAttributes;

  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  rev: number; // incrementing revision for optimistic concurrency
};

export type CreateTaskRequest = {
  title: string;
  description?: string;
  dueDate?: string;
  priority?: TaskPriority;
  effort?: EffortEstimate;
  minimumDuration?: DurationEstimate;
  attrs?: TaskAttributes;

  // Phase 4 (GTD) - optional for backward compatibility
  entityType?: EntityType;
  state?: WorkflowState;
  context?: string;
  contextIds?: string[];
  waitingFor?: string;
  waitingForTaskId?: string;
  waitingForTaskTitle?: string;
  resumeStateAfterWait?: "inbox" | "next";

  // Progress-aware duration model
  estimatedMinutes?: number;
  remainingMinutes?: number;
  timeSpentMinutes?: number;
};

export type CreateTaskResponse = { task: Task };

export type ListTasksResponse = {
  items: Task[];
  nextToken?: string;
};

export type UpdateTaskRequest = {
  title?: string;
  description?: string;

  /** Legacy status retained for compatibility. Server may ignore if `state` is provided. */
  status?: TaskStatus;

  /** Set to null to clear. */
  dueDate?: string | null;

  /** Set to null to clear. */
  priority?: TaskPriority | null;

  /** Set to null to clear. */
  effort?: EffortEstimate | null;

  /** Set to null to clear. */
  minimumDuration?: DurationEstimate | null;

  /** Set to null to clear. */
  attrs?: TaskAttributes | null;

  // Phase 4 (GTD)
  entityType?: EntityType;
  state?: WorkflowState;

  /** Set to null to clear. */
  context?: string | null;

  /** Set to null or [] to clear. */
  contextIds?: string[] | null;

  /** Set to null to clear. */
  waitingFor?: string | null;

  /** Set to null to clear. */
  waitingForTaskId?: string | null;

  /** Set to null to clear. */
  waitingForTaskTitle?: string | null;

  /** Set to null to clear. */
  resumeStateAfterWait?: "inbox" | "next" | null;

  /** Set to null to clear. */
  estimatedMinutes?: number | null;

  /** Set to null to clear. */
  remainingMinutes?: number | null;

  /** Set to null to clear. */
  timeSpentMinutes?: number | null;

  /** Optional optimistic concurrency guard. */
  expectedRev?: number;
};

export type UpdateTaskResponse = { task: Task };


// ----------------------------------------------------------------------
// Execution bucket read model

export type BucketTask = Task & {
  /**
   * Root task id for this task's hierarchy. For root items, this is the task's own id.
   * For nested tasks, this is the owning root task id.
   */
  rootTaskId?: string;

  /**
   * Present when the owning root is a project, so bucket UIs can show project context
   * without traversing the tree.
   */
  project?: {
    taskId: string;
    title: string;
  };
};

export type ListBucketTasksResponse = {
  items: BucketTask[];
  nextToken?: string;
};

export type BucketCountsResponse = {
  counts: Record<WorkflowState, number>;
};

// ----------------------------------------------------------------------
// Phase 2: Subtasks (tree model)

/**
 * Create a subtask under a parent task node.
 * Parent id is provided by the route.
 */
export type CreateSubtaskRequest = CreateTaskRequest;

export type CreateSubtaskResponse = { task: Task };

export type ListSubtasksResponse = {
  items: Task[];
  nextToken?: string;
};

/**
 * Update a subtask under a parent task node.
 * Parent id and subtask id are provided by the route.
 */
export type UpdateSubtaskRequest = UpdateTaskRequest;

export type UpdateSubtaskResponse = { task: Task };

export type ErrorResponse = {
  error: {
    code: string;
    message: string;
    details?: unknown;
    /** API Gateway request id (useful for support/debugging) */
    requestId?: string;
  };
};

// ----------------------------------------------------------------------
// Phase 3: Sharing

export type ShareMode = "VIEW" | "EDIT";

/**
 * Represents a share grant from an owner to a grantee for a root task.
 * Root-level share implies access to the entire subtree.
 */
export type ShareGrant = {
  rootTaskId: string;
  ownerSub: string;
  granteeSub: string;
  mode: ShareMode;
  createdAt: string; // ISO 8601
  updatedAt?: string; // ISO 8601
};

export type CreateShareRequest = {
  granteeSub: string;
  mode: ShareMode;
};

export type CreateShareResponse = {
  grant: ShareGrant;
};

export type ListSharesResponse = {
  items: ShareGrant[];
  nextToken?: string;
};

export type RevokeShareResponse = { ok: true };

export type SharedTaskPointer = {
  ownerSub: string;
  rootTaskId: string;
  mode: ShareMode;
  grantedAt: string; // ISO 8601
};

export type ListSharedWithMeResponse = {
  items: Array<SharedTaskPointer & { task?: Task }>;
  nextToken?: string;
};


// ----------------------------------------------------------------------
// Phase 8: Today dashboard

export type TodayTaskSource = "owned" | "shared";

export type TodayTask = Task & {
  source: TodayTaskSource;
  sharedMeta?: {
    ownerSub: string;
    rootTaskId: string;
    mode: ShareMode;
  };
};

export type TodayProjectHealthIssue = {
  project: TodayTask;
  issues: Array<"noNext" | "onlySomeday" | "stalledWaiting">;
  nextActions: number;
  stalledWaiting: number;
  openActions: number;
};

export type TodayResponse = {
  generatedAt: string;
  includeShared: boolean;
  overdue: TodayTask[];
  dueToday: TodayTask[];
  waiting: TodayTask[];
  recommended: TodayTask[];
  projectHealth: TodayProjectHealthIssue[];
};


export type TodayReasonChip =
  | "Ready to start"
  | "Due today"
  | "Overdue"
  | "Due soon"
  | "Fits 15 min block"
  | "Fits 30 min block"
  | "Fits 60 min block"
  | "Fits medium block"
  | "Small effort"
  | "Low activation friction"
  | "Deep work block"
  | "High leverage"
  | "Substantial progress"
  | "Time-sensitive"
  | "Only clear next step"
  | "Restores momentum"
  | "Clarifies project"
  | "Reduces deadline risk"
  | "Well defined"
  | "Scheduled for today";

export type TodayExecutionMode = "all" | "quickWins" | "mediumBlock" | "deepWork" | "dueSoon";

export type TodayRecommendationFit = "quick" | "medium" | "deep" | "unknown";
export type TodayRecommendationReadiness = "ready" | "weakReady" | "notReady" | "blocked";

export type TodayTaskProjectRef = {
  taskId: string;
  title: string;
};

export type TodayRecommendation = {
  task: TodayTask;
  project?: TodayTaskProjectRef;
  score: number;
  reasons: TodayReasonChip[];
  explanation?: string;
  executionFit?: TodayRecommendationFit;
  readiness?: TodayRecommendationReadiness;
};

export type TodayModeRecommendations = {
  mode: TodayExecutionMode;
  label: string;
  description: string;
  bestNextAction: TodayRecommendation | null;
  recommended: TodayRecommendation[];
};

export type TodayGuidedAction = {
  count: number;
  sampleTitles?: string[];
};

export type TodayGuidedActions = {
  processInbox?: TodayGuidedAction;
  followUpWaiting?: TodayGuidedAction;
  clarifyProjects?: TodayGuidedAction;
  reviveProjects?: TodayGuidedAction;
  unblockProjects?: TodayGuidedAction;
  breakLargeTasks?: TodayGuidedAction;
  prepareNextActions?: TodayGuidedAction;
};

export type TodayAttentionKind = "overdueWaiting" | "staleWaiting";

export type TodayAttentionItem = {
  task: TodayTask;
  kind: TodayAttentionKind;
  title: string;
  explanation: string;
  suggestedActionLabel: string;
};

export type TodayFallbackRecommendation = {
  kind: "attentionTask" | "guidedAction";
  title: string;
  description: string;
  targetView: "inbox" | "waiting" | "projects" | "tasks";
  ctaLabel: string;
  task?: TodayTask;
};

export type TodayExecutionMetrics = {
  readyTasks: number;
  overdueTasks: number;
  dueSoonTasks: number;
  blockedTasks: number;
  staleTasks: number;
  totalEffortMinutes: number;
};

export type ExecutionStateLevel = "calm" | "balanced" | "building" | "stressed" | "critical";

export type ExecutionStateSummary = {
  level: ExecutionStateLevel;
  summary: string;
  metrics: {
    actionableCount: number;
    overdueCount: number;
    dueSoonCount: number;
    blockedCount: number;
    staleCount: number;
    readyCount: number;
    remainingMinutes: number;
  };
};

export type ProjectMomentumTier = "strong" | "warm" | "cold" | "stalled";
export type ProjectClarityTier =
  | "clear"
  | "needsNextAction"
  | "needsClarification"
  | "blocked"
  | "parked";
export type ProjectReadinessTier = "ready" | "weakReady" | "blocked" | "notReady";
export type ProjectBlockageTier = "none" | "waiting" | "waitingRisk";

export type TodayProjectHealthProject = {
  project: TodayTask;
  leadTask?: TodayTaskProjectRef;
  diagnosis: string;
  severity: number;
  openActions: number;
  actionableCount: number;
  nextCount: number;
  inboxCount: number;
  waitingCount: number;
  dueSoonCount: number;
  recentCompletedCount: number;
  momentum: ProjectMomentumTier;
  clarity: ProjectClarityTier;
  readiness: ProjectReadinessTier;
  blockage: ProjectBlockageTier;
};

export type TodayProjectHealthSummary = {
  noClearNextStep: TodayProjectHealthProject[];
  blockedByWaiting: TodayProjectHealthProject[];
  deadlinePressure: TodayProjectHealthProject[];
  lowMomentum: TodayProjectHealthProject[];
};

export type TodayOverviewResponse = {
  generatedAt: string;
  includeShared: boolean;
  activeContextIds?: string[];
  includeNoContext?: boolean;
  defaultMode: TodayExecutionMode;
  executionMetrics: TodayExecutionMetrics;
  bestNextAction: TodayRecommendation | null;
  fallbackRecommendation: TodayFallbackRecommendation | null;
  attentionItems: TodayAttentionItem[];
  recommended: TodayRecommendation[];
  recommendationModes: Record<TodayExecutionMode, TodayModeRecommendations>;
  guidedActions: TodayGuidedActions;
  projectHealth: TodayProjectHealthSummary;
};

// ----------------------------------------------------------------------
// Phase 9: Review dashboard

export type ReviewMetricKey =
  | "inbox"
  | "projectsWithoutNext"
  | "waitingFollowups"
  | "staleTasks"
  | "oldSomeday"
  | "overdueScheduled";

export type ReviewCounts = {
  inboxCount: number;
  projectsWithoutNext: number;
  waitingFollowups: number;
  staleTasks: number;
  oldSomeday: number;
  overdueScheduled: number;
};

export type ReviewTaskBuckets = {
  inbox: TodayTask[];
  waitingFollowups: TodayTask[];
  staleTasks: TodayTask[];
  oldSomeday: TodayTask[];
  overdueScheduled: TodayTask[];
};

export type ReviewResponse = ReviewCounts & {
  generatedAt: string;
  includeShared: boolean;
  buckets: ReviewTaskBuckets;
  projectsWithoutNextItems: TodayProjectHealthIssue[];
};



// ----------------------------------------------------------------------
// Phase 10: Insights and guided actions

export type InsightSuggestionType =
  | "promoteToNext"
  | "projectMissingNextAction"
  | "waitingFollowUp"
  | "missingContext"
  | "missingEffort"
  | "missingMinimumDuration"
  | "repeatedDeferredLargeBlock"
  | "projectNextMissingMinimumDuration"
  | "scheduledWithoutDueDate"
  | "staleTask"
  | "oldSomeday";

export type InsightReasonCode =
  | "inbox_actionable"
  | "project_no_next"
  | "waiting_stale"
  | "context_missing"
  | "effort_missing"
  | "minimum_duration_missing"
  | "deferred_large_block"
  | "project_next_missing_minimum_duration"
  | "scheduled_no_due_date"
  | "task_stale"
  | "someday_old";

export type InsightRecommendedAction =
  | "set_next"
  | "create_next_action"
  | "set_waiting_followup"
  | "add_context"
  | "add_effort"
  | "add_minimum_duration"
  | "set_due_date"
  | "open_task";

export type InsightScoreBreakdown = {
  urgency: number;
  staleness: number;
  dueDateRisk: number;
  projectBlockage: number;
  missingMetadata: number;
  waitingFollowupRisk: number;
  total: number;
};

export type InsightSuggestion = {
  id: string;
  type: InsightSuggestionType;
  score: number;
  scoreBreakdown?: InsightScoreBreakdown;
  taskId?: string;
  projectId?: string;
  task?: TodayTask;
  project?: TodayTask;
  title: string;
  reason: string;
  reasonCode: InsightReasonCode;
  recommendedAction: InsightRecommendedAction;
};

export type InsightsResponse = {
  generatedAt: string;
  includeShared: boolean;
  suggestions: InsightSuggestion[];
};
