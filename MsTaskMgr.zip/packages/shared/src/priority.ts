
import type { TaskPriority } from "./index";

export const PRIORITY_LABELS: Record<TaskPriority, string> = {
  1: "P1 · Critical",
  2: "P2 · High",
  3: "P3 · Normal",
  4: "P4 · Low",
  5: "P5 · Very low",
};

/**
 * Canonical priority strength.
 * Higher returned values indicate stronger urgency / importance.
 * P1 is strongest, P5 is weakest.
 */
export function priorityRank(priority?: TaskPriority | null): number {
  if (typeof priority !== "number") return 0;
  return Math.max(0, 6 - priority);
}

export function priorityLabel(priority?: TaskPriority | null): string | null {
  if (typeof priority !== "number") return null;
  return PRIORITY_LABELS[priority as TaskPriority] ?? null;
}

export function comparePriorityDescending(
  a?: TaskPriority | null,
  b?: TaskPriority | null
): number {
  return priorityRank(b) - priorityRank(a);
}
